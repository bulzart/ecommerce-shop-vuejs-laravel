<?php

namespace App\Http\Livewire;

use Livewire\Component;
class Golf extends Component
{
    

    public function render()
    {
        return view('livewire.golf');
    }
}
